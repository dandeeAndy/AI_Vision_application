# import sys
import glob
import cv2

img_files = sorted(glob.glob('.\images\*.jpg'))
for f in img_files:
    print(f)

cnt = len(img_files) # 총 이미지 파일 개수
idx = 0

cv2.namedWindow('images')

while True:
    img = cv2.imread(img_files[idx])
    
    cv2.imshow('images', img)
    
    keycode = cv2.waitKey(0)
    if keycode == ord('u'): # page up
        idx += 1

    if keycode == ord('d'): # page down
        idx -= 1
            
    elif keycode == ord('q'): # 창이 닫힘
        break
            
    
    
    if idx >= cnt:
        idx = 0
    elif idx < 0:
        idx = cnt-1  
            
    
cv2.destroyAllWindows()