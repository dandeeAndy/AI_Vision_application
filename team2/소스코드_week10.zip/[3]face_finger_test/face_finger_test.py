
import cv2
from cvzone.HandTrackingModule import HandDetector
import mediapipe as mp


# WebCam 을 사용할 경우
cap = cv2.VideoCapture(0)

mp_face_detection=mp.solutions.face_detection
mp_drawing=mp.solutions.drawing_utils

face_detection=mp_face_detection.FaceDetection(model_selection=1,min_detection_confidence=0.85)
 
# 손을 감지
detector = HandDetector(maxHands=1, detectionCon=0.8)
FLAG=-1 #
fingerup = None

frm=0
FINGER=None
keypoints=None
nose=None
while True:

    frm+=1
    
    # 웹켐에서 프레임 가져오기
    success, img = cap.read()
    img_copy = img.copy()

    res=face_detection.process(cv2.cvtColor(img,cv2.COLOR_BGR2RGB))
    if res.detections:
        for detection in res.detections:    
            mp_drawing.draw_detection(img,detection)     
            keypoints = detection.location_data.relative_keypoints
            nose = keypoints[2]
            h, w, _ = img_copy.shape
            nose = (int(nose.x * w), int(nose.y * h))            
            #******************************
             
    hands, img = detector.findHands(img)
    if hands: 
                
            hands_data = hands[0]
            right_left = hands_data['type']
            print(right_left) # RIGHT or LEFT 선별
            finPos = hands_data['lmList']
                
            if hands_data: 
            
                fingerup = detector.fingersUp(hands_data)  # 손가락 모양
                print(fingerup)
                print()

    cv2.imshow("Image", img)
    if cv2.waitKey(1) == ord("q"): # q 누를 시 웹켐 종료
        break
    
cap.release()