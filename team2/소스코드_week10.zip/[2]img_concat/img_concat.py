import numpy as np
import cv2

# 이미지 불러오기
img1 = cv2.imread("dog.jpg", cv2.IMREAD_COLOR)
img2 = cv2.imread("cat.jpg", cv2.IMREAD_COLOR)

# 이미지 리사이즈(이미지를 합치기 위해 필요)
hor = 300 # 변환될 가로 픽셀 사이즈
ver = 500 # 변환될 세로 픽셀 사이즈
img1_re = cv2.resize(img1, (hor, ver)) 
img2_re = cv2.resize(img2, (hor, ver)) 

# 두 개의 이미지 합치기(horizontal)
img_concat1 = np.concatenate((img1_re, img2_re), axis=1)
cv2.imshow('img_concat(horizontal)', img_concat1)

# 두 개의 이미지 합치기(vertical)
img_concat2 = np.concatenate((img1_re, img2_re), axis=0)
cv2.imshow('img_concat(vertical)', img_concat2)

cv2.waitKey(0) # 키를 누를 때까지 창을 띄워놓음
cv2.destroyAllWindows() # 키보드 자판의 아무 키나 누르면 창이 닫힘